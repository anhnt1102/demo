declare module "appium-ios-simulator";
