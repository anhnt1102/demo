declare module "appium-base-driver";
