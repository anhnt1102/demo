declare module "mjpeg-proxy";
