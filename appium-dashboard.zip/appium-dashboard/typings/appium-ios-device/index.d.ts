declare module "appium-ios-device";
