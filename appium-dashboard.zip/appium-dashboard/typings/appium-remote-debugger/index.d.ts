declare module "appium-remote-debugger";
