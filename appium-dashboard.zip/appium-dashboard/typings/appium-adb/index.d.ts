declare module "appium-adb";
declare module "appium-adb/lib/logcat";
