declare module '@appium/base-plugin';
